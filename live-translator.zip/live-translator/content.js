// content.js
// Watches all text inputs on the page.
// Sends text to the background worker for translation and shows a floating preview.

(function () {
  // Avoid injecting twice on the same page
  if (window.__liveTranslatorLoaded) return;
  window.__liveTranslatorLoaded = true;

  // ─── State ─────────────────────────────────────────────────────────────

  let debounceTimer = null;
  let activePreview = null;
  let pendingElement = null;   // the input we're waiting on a result for
  let pendingText = null;      // the text we sent for translation

  // ─── Input Listeners ───────────────────────────────────────────────────

  function attachToInputs() {
    const selectors = [
      "input[type='text']",
      "input[type='search']",
      "input:not([type])",
      "textarea",
      "[contenteditable='true']"
    ];
    document.querySelectorAll(selectors.join(", ")).forEach(attachListener);
  }

  function attachListener(el) {
    if (el.dataset.ltAttached) return;
    el.dataset.ltAttached = "true";

    el.addEventListener("input", onInput);
    el.addEventListener("blur", () => setTimeout(removePreview, 200));
    el.addEventListener("keydown", onKeydown);
  }

  function onInput(e) {
    clearTimeout(debounceTimer);
    const text = getTextValue(e.target).trim();

    if (!text || text.length < 3) {
      removePreview();
      return;
    }

    // Show a "waiting to type" indicator after 400ms
    debounceTimer = setTimeout(() => {
      pendingElement = e.target;
      pendingText = text;
      showWaiting(e.target);

      // Send translation request to background worker
      chrome.runtime.sendMessage({ type: "TRANSLATE", text });
    }, 650);
  }

  // Press Escape to dismiss the preview
  function onKeydown(e) {
    if (e.key === "Escape") removePreview();
  }

  function getTextValue(el) {
    return el.isContentEditable ? el.innerText : el.value;
  }

  function setTextValue(el, text) {
    if (el.isContentEditable) {
      el.innerText = text;
    } else {
      el.value = text;
    }
    // Trigger the page's own event listeners (important for SPAs like Google)
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // ─── Message Listener ──────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg) => {
    if (!pendingElement) return;

    if (msg.type === "TRANSLATION_RESULT") {
      // Only show if the input still has the same text we sent
      const currentText = getTextValue(pendingElement).trim();
      if (currentText !== pendingText) return;

      showPreview(msg.translated, msg.direction, pendingElement);
    }

    if (msg.type === "TRANSLATION_ERROR") {
      showError(pendingElement, msg.error);
    }

    if (msg.type === "MODEL_PROGRESS") {
      updateLoadingProgress(msg.pct, msg.model);
    }
  });

  // ─── Preview UI ────────────────────────────────────────────────────────

  function showWaiting(el) {
    removePreview();
    const preview = buildPreviewShell(el);

    preview.innerHTML = `
      <div class="lt-spinner"></div>
      <span class="lt-label">Translating…</span>
    `;

    mountPreview(preview, el);
  }

  function updateLoadingProgress(pct, model) {
    const label = document.querySelector("#lt-preview .lt-label");
    if (label) {
      const name = model === "enToJa" ? "EN→JA" : "JA→EN";
      label.textContent = `Downloading ${name} model: ${pct}%`;
    }
  }

  function showPreview(translated, direction, el) {
    removePreview();
    const preview = buildPreviewShell(el);

    preview.innerHTML = `
      <span class="lt-direction">${direction}</span>
      <span class="lt-text">${escapeHtml(translated)}</span>
      <button class="lt-btn lt-copy" title="Copy translation">⎘</button>
      <button class="lt-btn lt-use" title="Replace your text with this translation">⇄ Use</button>
    `;

    mountPreview(preview, el);

    preview.querySelector(".lt-use").addEventListener("click", () => {
      setTextValue(el, translated);
      removePreview();
      el.focus();
    });

    preview.querySelector(".lt-copy").addEventListener("click", () => {
      navigator.clipboard.writeText(translated).then(() => {
        const btn = preview.querySelector(".lt-copy");
        btn.textContent = "✓";
        setTimeout(() => btn.textContent = "⎘", 1500);
      });
    });
  }

  function showError(el, errorMsg) {
    removePreview();
    const isRateLimit = errorMsg && errorMsg.includes("Daily limit");

    if (isRateLimit) {
      // Persistent full-page banner — hard to miss
      const banner = document.createElement("div");
      banner.id = "lt-rate-limit-banner";
      banner.innerHTML = `
        <span>🚫 <strong>MyMemory daily limit reached</strong> (1000 req/day). Resets at midnight UTC.</span>
        <button id="lt-banner-close">✕</button>
      `;
      Object.assign(banner.style, {
        position: "fixed",
        top: "0", left: "0", right: "0",
        background: "#fab387",
        color: "#1e1e2e",
        padding: "10px 16px",
        fontSize: "13px",
        fontFamily: "sans-serif",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        zIndex: "2147483647",
        boxShadow: "0 2px 8px rgba(0,0,0,0.3)"
      });
      document.body.appendChild(banner);
      document.getElementById("lt-banner-close").addEventListener("click", () => banner.remove());
    } else {
      const preview = buildPreviewShell(el);
      preview.innerHTML = `<span class="lt-error">⚠ Translation failed. Check your connection.</span>`;
      mountPreview(preview, el);
      setTimeout(removePreview, 3000);
    }
  }

  function buildPreviewShell(el) {
    const preview = document.createElement("div");
    preview.id = "lt-preview";

    // Inject styles once
    if (!document.getElementById("lt-styles")) {
      const style = document.createElement("style");
      style.id = "lt-styles";
      style.textContent = `
        #lt-preview {
          position: fixed;
          z-index: 2147483647;
          background: #1e1e2e;
          color: #cdd6f4;
          border: 1px solid #313244;
          border-radius: 10px;
          padding: 9px 14px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          font-size: 13px;
          display: flex;
          align-items: center;
          gap: 10px;
          max-width: 480px;
          min-width: 160px;
          box-shadow: 0 6px 24px rgba(0,0,0,0.45);
          transition: opacity 0.15s ease;
          pointer-events: all;
        }
        .lt-direction {
          color: #89b4fa;
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .lt-text {
          flex: 1;
          line-height: 1.4;
          word-break: break-word;
        }
        .lt-label {
          opacity: 0.6;
          font-style: italic;
        }
        .lt-error {
          color: #f38ba8;
        }
        .lt-btn {
          background: #313244;
          color: #cdd6f4;
          border: none;
          border-radius: 6px;
          padding: 4px 10px;
          font-size: 12px;
          cursor: pointer;
          white-space: nowrap;
          transition: background 0.1s;
        }
        .lt-btn:hover { background: #45475a; }
        .lt-use { background: #89b4fa; color: #1e1e2e; font-weight: 600; }
        .lt-use:hover { background: #74c7ec; }
        .lt-spinner {
          width: 14px; height: 14px;
          border: 2px solid #45475a;
          border-top-color: #89b4fa;
          border-radius: 50%;
          animation: lt-spin 0.7s linear infinite;
          flex-shrink: 0;
        }
        @keyframes lt-spin { to { transform: rotate(360deg); } }
      `;
      document.head.appendChild(style);
    }

    return preview;
  }

  function mountPreview(preview, el) {
    const rect = el.getBoundingClientRect();

    // Position below the input, aligned to its left edge
    let top = rect.bottom + 6;
    let left = rect.left;

    // Clamp to viewport so it never goes off-screen
    const viewportW = window.innerWidth;
    const maxLeft = viewportW - 500; // rough max width
    left = Math.max(8, Math.min(left, maxLeft));

    // If too close to bottom, show above the input instead
    if (top + 60 > window.innerHeight) {
      top = rect.top - 54;
    }

    preview.style.top = `${top}px`;
    preview.style.left = `${left}px`;

    document.body.appendChild(preview);
    activePreview = preview;
  }

  function removePreview() {
    if (activePreview) {
      activePreview.remove();
      activePreview = null;
    }
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ─── Observer ──────────────────────────────────────────────────────────
  // Watch for new inputs added dynamically (SPAs, modals, etc.)

  const observer = new MutationObserver(() => attachToInputs());
  observer.observe(document.documentElement, { childList: true, subtree: true });

  attachToInputs();

})();
