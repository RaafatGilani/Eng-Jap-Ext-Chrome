// popup.js

const STATUS_LABELS = {
  unloaded: { text: "Not loaded",  cls: "badge-unloaded" },
  loading:  { text: "Loading…",    cls: "badge-loading"  },
  ready:    { text: "Ready ✓",     cls: "badge-ready"    },
  error:    { text: "Error ✗",     cls: "badge-error"    }
};

function applyStatus(elementId, status) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const info = STATUS_LABELS[status] || STATUS_LABELS.unloaded;

  el.textContent = info.text;
  el.className = `badge ${info.cls}`;
}

function updateUI(modelStatus) {
  applyStatus("status-enToJa", modelStatus.enToJa);
  applyStatus("status-jaToEn", modelStatus.jaToEn);

  const btn = document.getElementById("preload-btn");
  const allReady = modelStatus.enToJa === "ready" && modelStatus.jaToEn === "ready";
  const anyLoading = modelStatus.enToJa === "loading" || modelStatus.jaToEn === "loading";

  if (allReady) {
    btn.textContent = "✓ Models Ready";
    btn.disabled = true;
  } else if (anyLoading) {
    btn.textContent = "⏳ Downloading…";
    btn.disabled = true;
  } else {
    btn.textContent = "⬇ Download Models Now";
    btn.disabled = false;
  }
}

// Fetch current model status from the background worker
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
  if (response?.modelStatus) {
    updateUI(response.modelStatus);
  }
});

// Poll every second so the popup stays updated while models load
const poller = setInterval(() => {
  chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
    if (chrome.runtime.lastError) {
      clearInterval(poller);
      return;
    }
    if (response?.modelStatus) {
      updateUI(response.modelStatus);
    }
  });
}, 1000);

// Trigger model preload when button is clicked
document.getElementById("preload-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "PRELOAD" });
});
