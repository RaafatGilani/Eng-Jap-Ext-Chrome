#!/bin/bash

# Live Translator - One-time setup script
# Downloads Transformers.js into the extension so it works fully offline

echo "📦 Setting up Live Translator extension..."
echo ""

LIB_DIR="$(dirname "$0")/lib"
mkdir -p "$LIB_DIR"


BASE_URL="https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist"

# Files to download: the main JS + all WASM backends
FILES=(
  "transformers.min.js"
  "ort-wasm.wasm"
  "ort-wasm-simd.wasm"
  "ort-wasm-threaded.wasm"
  "ort-wasm-simd-threaded.wasm"
)

download() {
  local url="$1"
  local dest="$2"
  if [ -f "$dest" ] && [ -s "$dest" ]; then
    echo "  ✓ $(basename $dest) already exists, skipping."
    return 0
  fi
  echo "  ⬇  $(basename $dest)..."
  if command -v curl &> /dev/null; then
    curl -L --progress-bar "$url" -o "$dest"
  elif command -v wget &> /dev/null; then
    wget -q --show-progress "$url" -O "$dest"
  else
    echo "❌ Neither curl nor wget found."
    exit 1
  fi
}

echo "⬇️  Downloading Transformers.js + WASM backends..."
echo ""

for FILE in "${FILES[@]}"; do
  download "$BASE_URL/$FILE" "$LIB_DIR/$FILE"
done

# Verify all files exist
MISSING=0
for FILE in "${FILES[@]}"; do
  if [ ! -s "$LIB_DIR/$FILE" ]; then
    echo "❌ Missing: $FILE"
    MISSING=1
  fi
done

if [ "$MISSING" -eq 0 ]; then
  TOTAL=$(du -sh "$LIB_DIR" | cut -f1)
  echo ""
  echo "✅ Done! All files downloaded ($TOTAL total)"
  echo ""
  echo "👉 Next steps:"
  echo "   1. Open Chrome and go to chrome://extensions"
  echo "   2. Enable Developer Mode (top right)"
  echo "   3. Click 'Load unpacked' and select this folder"
  echo "   4. Start typing in any text box!"
  echo ""
  echo "📝 Note: The first translation will download the language model (~100MB)."
  echo "   After that, everything works fully offline."
else
  echo "❌ Some files failed to download. Please check your internet connection."
  exit 1
fi
