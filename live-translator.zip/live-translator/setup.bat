@echo off
REM Live Translator - One-time setup script (Windows)
REM Downloads Transformers.js into the extension so it works fully offline

echo 📦 Setting up Live Translator extension...
echo.

set LIB_DIR=%~dp0lib
if not exist "%LIB_DIR%" mkdir "%LIB_DIR%"

set BASE=https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist

echo ⬇️  Downloading Transformers.js + WASM backends...
echo.

powershell -Command " ^
  $files = @('transformers.min.js','ort-wasm.wasm','ort-wasm-simd.wasm','ort-wasm-threaded.wasm','ort-wasm-simd-threaded.wasm'); ^
  foreach ($f in $files) { ^
    $dest = '%LIB_DIR%\' + $f; ^
    if (Test-Path $dest) { Write-Host ('  skipping ' + $f) } ^
    else { Write-Host ('  downloading ' + $f + '...'); Invoke-WebRequest -Uri ('%BASE%/' + $f) -OutFile $dest -UseBasicParsing } ^
  } ^
"

if exist "%LIB_DIR%\transformers.min.js" (
  echo.
  echo ✅ Done! All files downloaded.
  echo.
  echo 👉 Next steps:
  echo    1. Open Chrome and go to chrome://extensions
  echo    2. Enable Developer Mode (top right)
  echo    3. Click 'Load unpacked' and select this folder
  echo    4. Start typing in any text box!
  echo.
  echo 📝 Note: The first translation downloads the language model (~100MB).
  echo    After that, everything works fully offline.
) else (
  echo ❌ Download failed. Please check your internet connection.
)

:end
pause
