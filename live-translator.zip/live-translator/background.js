// background.js
// Translates using the MyMemory free API.
// No API key, no account, no model download. Just works.
// Limit: 1000 requests/day for personal use.

const MYMEMORY_URL = "https://api.mymemory.translated.net/get";

// ─── Language Detection ────────────────────────────────────────────────────

function isJapanese(text) {
  const japanesePattern = /[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]/g;
  const matches = text.match(japanesePattern) || [];
  return matches.length / text.length > 0.2;
}

// ─── Translation ───────────────────────────────────────────────────────────

async function translate(text) {
  const japanese = isJapanese(text);
  const langPair = japanese ? "ja|en" : "en|ja";
  const direction = japanese ? "JA → EN" : "EN → JA";

  const url = `${MYMEMORY_URL}?q=${encodeURIComponent(text)}&langpair=${langPair}`;
  const response = await fetch(url);

  if (!response.ok) throw new Error(`HTTP error ${response.status}`);

  const data = await response.json();

  // MyMemory returns status 429 inside the JSON when rate limited
  if (data.responseStatus === 429) {
    throw new Error("Daily limit reached (1000 requests/day). Try again tomorrow.");
  }

  const translated = data.responseData?.translatedText;
  if (!translated) throw new Error("No translation returned");

  return { translated, direction };
}

// ─── Message Handler ───────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === "TRANSLATE") {
    translate(msg.text.trim())
      .then(({ translated, direction }) => {
        chrome.tabs.sendMessage(sender.tab.id, {
          type: "TRANSLATION_RESULT",
          translated,
          direction,
          originalText: msg.text
        });
      })
      .catch((err) => {
        chrome.tabs.sendMessage(sender.tab.id, {
          type: "TRANSLATION_ERROR",
          error: err.message
        });
      });

    return true;
  }

  // Popup asks for model status — report as always ready since no model needed
  if (msg.type === "GET_STATUS") {
    sendResponse({
      modelStatus: { enToJa: "ready", jaToEn: "ready" }
    });
    return true;
  }

  if (msg.type === "PRELOAD") {
    sendResponse({ ok: true });
    return true;
  }
});

console.log("[Translator] Background worker started. Using MyMemory API.");
